"""
Ratio by Konta & Cie: серверная функция (Yandex Cloud Functions, Python 3.12).

Что делает:
  connect     проверяет read-only ключ биржи и хранит его зашифрованным
  disconnect  удаляет ключ
  sync        загружает закрытые сделки со всех подключенных бирж и Т-Инвестиций
  coach       подробный разбор журнала языковой моделью
  (таймер)    каждые 15 минут подтягивает сделки и включает стоп-кран в Telegram

Переменные окружения:
  BOT_TOKEN       токен бота Ratio (для проверки initData и сообщений стоп-крана)
  RATIO_KEY       ключ шифрования Fernet (сгенерировать один раз, не менять)
  BUCKET          имя бакета Object Storage
  S3_KEY_ID, S3_SECRET   статический ключ сервисного аккаунта с доступом к бакету
  LLM_URL, LLM_KEY, LLM_MODEL   OpenAI-совместимый чат, по умолчанию YandexGPT
  PROXY           необязательно: https-прокси за рубежом для бирж с гео-блоком
"""
import base64, calendar, hashlib, hmac, json, os, time, urllib.parse
from collections import defaultdict, deque

import boto3
import ccxt
import requests
from cryptography.fernet import Fernet

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
FERNET = Fernet(os.environ["RATIO_KEY"].encode()) if os.environ.get("RATIO_KEY") else None
BUCKET = os.environ.get("BUCKET", "")
LLM_URL = os.environ.get("LLM_URL", "https://llm.api.cloud.yandex.net/v1/chat/completions")
LLM_KEY = os.environ.get("LLM_KEY", "")
LLM_MODEL = os.environ.get("LLM_MODEL", "")

CCXT_IDS = {"bybit", "binance", "okx", "bingx", "bitget", "mexc", "gate", "htx", "kucoin", "bybit-testnet"}
NEEDS_PASS = {"okx", "bitget", "kucoin"}
HISTORY_DAYS = 90
CORS = {"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json"}

s3 = boto3.client("s3", endpoint_url="https://storage.yandexcloud.net", region_name="ru-central1",
                  aws_access_key_id=os.environ.get("S3_KEY_ID"), aws_secret_access_key=os.environ.get("S3_SECRET"))


class UserError(Exception):
    pass


# ---------------- хранилище ----------------
def load_user(uid):
    try:
        return json.loads(s3.get_object(Bucket=BUCKET, Key=f"users/{uid}.json")["Body"].read())
    except s3.exceptions.NoSuchKey:
        return {"conns": {}, "cursor": {}, "rules": {}, "alerted": ""}


def save_user(uid, u):
    s3.put_object(Bucket=BUCKET, Key=f"users/{uid}.json", Body=json.dumps(u).encode())


def enc(v):
    return FERNET.encrypt(v.encode()).decode() if v else ""


def dec(v):
    return FERNET.decrypt(v.encode()).decode() if v else ""


# ---------------- авторизация Telegram ----------------
def check_init_data(init_data):
    if not init_data:
        raise UserError("Откройте Ratio внутри Telegram")
    pairs = dict(urllib.parse.parse_qsl(init_data, keep_blank_values=True))
    got = pairs.pop("hash", "")
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    if not hmac.compare_digest(hmac.new(secret, check.encode(), hashlib.sha256).hexdigest(), got):
        raise UserError("Сессия Telegram не прошла проверку")
    if time.time() - int(pairs.get("auth_date", 0)) > 7 * 86400:
        raise UserError("Сессия устарела, перезапустите приложение")
    return str(json.loads(pairs["user"])["id"])


# ---------------- общее: склейка исполнений в сделки ----------------
def fifo_round_trips(fills, src, cur):
    """fills: [{sym, side buy/sell, qty, price, ts, fee}] -> закрытые лонги (спот и акции)."""
    out, books = [], defaultdict(deque)
    for f in sorted(fills, key=lambda x: x["ts"]):
        book = books[f["sym"]]
        if f["side"] == "buy":
            book.append([f["qty"], f["price"], f["ts"], f.get("fee", 0.0)])
            continue
        left, cost, qty, opened, fees = f["qty"], 0.0, 0.0, None, f.get("fee", 0.0)
        while left > 1e-12 and book:
            lot = book[0]
            take = min(left, lot[0])
            cost += take * lot[1]
            qty += take
            fees += lot[3] * take / lot[0] if lot[0] else 0
            opened = opened or lot[2]
            lot[0] -= take
            lot[3] -= lot[3] * take / (lot[0] + take) if lot[0] + take else 0
            left -= take
            if lot[0] <= 1e-12:
                book.popleft()
        if qty <= 0:
            continue  # продажа без известной покупки (куплено раньше окна истории)
        entry = cost / qty
        out.append({"id": f"{src}:{f['sym']}:{f['ts']}", "t": f["sym"], "s": "long", "e": entry, "x": f["price"],
                    "q": qty, "p": (f["price"] - entry) * qty - fees, "c": cur, "ts": f["ts"], "st": None, "src": src})
    return out


# ---------------- криптобиржи через ccxt ----------------
def make_exchange(ex_id, key, secret, password):
    test = ex_id.endswith("-testnet")
    cls = getattr(ccxt, ex_id.replace("-testnet", ""))
    cfg = {"apiKey": key, "secret": secret, "enableRateLimit": True, "timeout": 15000}
    if password:
        cfg["password"] = password
    if os.environ.get("PROXY"):  # для бирж, которые не отвечают на российские IP
        cfg["httpsProxy"] = os.environ["PROXY"]
    ex = cls(cfg)
    if test:  # демо-счет биржи с ненастоящими деньгами
        ex.set_sandbox_mode(True)
    return ex


def base_of(symbol):
    return symbol.split("/")[0].split(":")[0]


def import_ccxt(ex_id, ex, since):
    trades, errors = [], []
    ex.load_markets()
    # 1. фьючерсы: закрытые позиции с реализованным PnL
    if ex.has.get("fetchPositionsHistory"):
        try:
            for p in ex.fetch_positions_history(None, since, 100) or []:
                qty = abs(float(p.get("contracts") or 0) * float(p.get("contractSize") or 1))
                entry = float(p.get("entryPrice") or 0)
                pnl = p.get("realizedPnl")
                ts = int(p.get("lastUpdateTimestamp") or p.get("timestamp") or 0)
                if not (qty and entry and pnl is not None and ts):
                    continue
                pnl, side = float(pnl), (p.get("side") or "long")
                exit_px = p.get("info", {}).get("avgExitPrice") or p.get("markPrice")
                exit_px = float(exit_px) if exit_px else entry + (pnl / qty if side == "long" else -pnl / qty)
                trades.append({"id": f"{ex_id}:pos:{p.get('id') or p['symbol']}:{ts}", "t": base_of(p["symbol"]),
                               "s": side, "e": entry, "x": exit_px, "q": qty, "p": pnl, "c": "$", "ts": ts,
                               "st": None, "src": ex_id, "lev": p.get("leverage")})
        except Exception as e:  # у части бирж история позиций требует символ или не поддерживается
            errors.append(f"{ex_id}: фьючерсы недоступны ({type(e).__name__})")
    # 2. спот: исполнения, склеенные в сделки
    fills = []
    try:
        raw = ex.fetch_my_trades(None, since, 500)
    except Exception:
        raw = []
        try:  # биржи, которым нужен символ: перебираем монеты с балансом
            bal = ex.fetch_balance().get("total", {})
            for asset, amt in bal.items():
                sym = f"{asset}/USDT"
                if amt and asset != "USDT" and sym in ex.markets:
                    raw += ex.fetch_my_trades(sym, since, 500)
        except Exception as e:
            errors.append(f"{ex_id}: спот недоступен ({type(e).__name__})")
    for t in raw:
        m = ex.markets.get(t["symbol"], {})
        if m and not m.get("spot", False):
            continue
        fee = t.get("fee") or {}
        fee_q = float(fee.get("cost") or 0) if fee.get("currency") in ("USDT", "USDC", "USD") else 0.0
        fills.append({"sym": base_of(t["symbol"]), "side": t["side"], "qty": float(t["amount"]),
                      "price": float(t["price"]), "ts": int(t["timestamp"]), "fee": fee_q})
    trades += fifo_round_trips(fills, ex_id, "$")
    return trades, errors


# ---------------- Т-Инвестиции ----------------
TINV = "https://invest-public-api.tinkoff.ru/rest/tinkoff.public.invest.api.contract.v1."


def tinv(token, method, body):
    r = requests.post(TINV + method, json=body, timeout=20,
                      headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    if r.status_code == 401:
        raise UserError("Токен Т-Инвестиций не подходит")
    r.raise_for_status()
    return r.json()


def money_val(m):
    return int(m.get("units", 0)) + int(m.get("nano", 0)) / 1e9 if m else 0.0


def import_tinvest(token, since):
    names, fills = {}, []
    accounts = tinv(token, "UsersService/GetAccounts", {}).get("accounts", [])
    frm = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(since / 1000))
    to = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    for acc in accounts:
        ops = tinv(token, "OperationsService/GetOperations",
                   {"accountId": acc["id"], "from": frm, "to": to, "state": "OPERATION_STATE_EXECUTED"}).get("operations", [])
        for o in ops:
            kind = o.get("operationType")
            if kind not in ("OPERATION_TYPE_BUY", "OPERATION_TYPE_SELL") or not o.get("figi"):
                continue
            figi = o["figi"]
            if figi not in names:
                ins = tinv(token, "InstrumentsService/GetInstrumentBy", {"idType": "INSTRUMENT_ID_TYPE_FIGI", "id": figi})
                names[figi] = ins.get("instrument", {}).get("ticker", figi)
            if (o.get("price") or {}).get("currency", "rub") != "rub":
                continue
            ts = calendar.timegm(time.strptime(o["date"][:19], "%Y-%m-%dT%H:%M:%S")) * 1000
            fills.append({"sym": names[figi], "side": "buy" if kind.endswith("BUY") else "sell",
                          "qty": float(o.get("quantity", 0)), "price": money_val(o.get("price")), "ts": ts})
    return fifo_round_trips(fills, "tinvest", "₽"), []


# ---------------- действия ----------------
def act_connect(uid, b):
    ex_id, key, secret, pw = b.get("exchange"), b.get("apiKey", "").strip(), b.get("secret", "").strip(), b.get("password", "").strip()
    if ex_id == "tinvest":
        if not key:
            raise UserError("Нужен токен")
        tinv(key, "UsersService/GetAccounts", {})
    elif ex_id in CCXT_IDS:
        if not (key and secret) or (ex_id in NEEDS_PASS and not pw):
            raise UserError("Заполните все поля ключа")
        try:
            make_exchange(ex_id, key, secret, pw).fetch_balance()
        except ccxt.AuthenticationError:
            raise UserError("Биржа не приняла ключ")
        except ccxt.PermissionDenied:
            raise UserError("У ключа нет права на чтение")
        except ccxt.NetworkError:
            raise UserError("Биржа сейчас недоступна с сервера")
    else:
        raise UserError("Неизвестная биржа")
    u = load_user(uid)
    u["conns"][ex_id] = {"k": enc(key), "s": enc(secret), "p": enc(pw)}
    u["cursor"].pop(ex_id, None)
    save_user(uid, u)
    return {"ok": True}


def act_disconnect(uid, b):
    u = load_user(uid)
    u["conns"].pop(b.get("exchange"), None)
    u["cursor"].pop(b.get("exchange"), None)
    save_user(uid, u)
    return {"ok": True}


def pull(u):
    all_trades, errors = [], []
    floor = int((time.time() - HISTORY_DAYS * 86400) * 1000)
    for ex_id, c in u["conns"].items():
        since = max(floor, u["cursor"].get(ex_id, floor) - 86400000)  # сутки перекрытия, дубли отсекает клиент
        try:
            if ex_id == "tinvest":
                t, e = import_tinvest(dec(c["k"]), since)
            else:
                t, e = import_ccxt(ex_id, make_exchange(ex_id, dec(c["k"]), dec(c["s"]), dec(c["p"])), since)
            all_trades += t
            errors += e
            if t:
                u["cursor"][ex_id] = max(x["ts"] for x in t)
        except UserError as e:
            errors.append(str(e))
        except Exception as e:
            errors.append(f"{ex_id}: не удалось загрузить ({type(e).__name__})")
    return all_trades, errors


def act_sync(uid, b):
    u = load_user(uid)
    if isinstance(b.get("rules"), dict):
        u["rules"] = b["rules"]
    trades, errors = pull(u)
    save_user(uid, u)
    return {"trades": trades, "errors": errors}


COACH_PROMPT = (
    "Ты коуч по трейдинговой дисциплине в приложении Ratio. Тебе дают журнал сделок пользователя и его правила. "
    "Найди 3-5 самых дорогих повторяющихся ошибок поведения: время, эмоции, отыгрыш после убытков, плечо, стопы, "
    "отдельные тикеры. Опирайся только на цифры из журнала, приводи их. Дай по каждой ошибке одно конкретное правило "
    "на следующую неделю. Не давай прогнозов рынка и советов купить или продать конкретный актив. "
    "Пиши по-русски, коротко, на ты, без воды, без буквы ё и без длинных тире. Без markdown-заголовков."
)


def act_coach(uid, b):
    if not (LLM_KEY and LLM_MODEL):
        raise UserError("AI-разбор еще не настроен на сервере")
    trades = b.get("trades", [])[:200]
    rows = [{"t": x.get("t"), "side": x.get("s"), "pnl": round(float(x.get("p") or 0), 2),
             "stop": bool(x.get("st")), "tags": x.get("tags", []),
             "time": time.strftime("%a %H:%M", time.gmtime((x.get("ts") or 0) / 1000 + 3 * 3600)), "note": (x.get("n") or "")[:120]}
            for x in trades]
    msg = json.dumps({"currency": b.get("cur"), "rules": b.get("rules"), "trades": rows}, ensure_ascii=False)
    r = requests.post(LLM_URL, timeout=60, headers={"Authorization": f"Bearer {LLM_KEY}"},
                      json={"model": LLM_MODEL, "temperature": 0.3, "max_tokens": 900,
                            "messages": [{"role": "system", "content": COACH_PROMPT}, {"role": "user", "content": msg}]})
    r.raise_for_status()
    return {"text": r.json()["choices"][0]["message"]["content"].replace("ё", "е").replace("—", ":")}


# ---------------- стоп-кран по таймеру ----------------
def tg_send(chat_id, text):
    requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", timeout=10,
                  json={"chat_id": chat_id, "text": text})


def brake_check(uid, u, trades):
    """Считает сегодняшние сделки (по московскому времени) против правил и пишет один раз в день."""
    msk = time.gmtime(time.time() + 3 * 3600)
    day = time.strftime("%Y-%m-%d", msk)
    start = int((time.time() - (msk.tm_hour * 3600 + msk.tm_min * 60 + msk.tm_sec)) * 1000)
    if u.get("alerted") == day:
        return
    for cur, r in (u.get("rules") or {}).items():
        today = sorted([t for t in trades if t["c"] == cur and t["ts"] >= start], key=lambda t: t["ts"])
        if not today or not r.get("dep"):
            continue
        loss = -sum(t["p"] for t in today)
        streak = 0
        for t in reversed(today):
            if t["p"] >= 0:
                break
            streak += 1
        why = []
        if loss > 0 and loss / r["dep"] * 100 >= r.get("day", 1e9):
            why.append(f"убыток за день {loss / r['dep'] * 100:.1f}% при лимите {r['day']}%")
        if len(today) >= r.get("max", 1e9):
            why.append(f"сделок сегодня {len(today)} при лимите {r['max']}")
        if r.get("pause") and streak >= r["pause"]:
            why.append(f"{streak} стопа подряд")
        if why:
            tg_send(uid, "Стоп-кран Ratio.\n\n" + "; ".join(why).capitalize() +
                    ".\n\nВы сами просили остановить вас здесь. На сегодня все.")
            u["alerted"] = day
            return


def on_timer():
    token = None
    while True:
        kw = {"Bucket": BUCKET, "Prefix": "users/"}
        if token:
            kw["ContinuationToken"] = token
        page = s3.list_objects_v2(**kw)
        for obj in page.get("Contents", []):
            uid = obj["Key"][6:-5]
            try:
                u = load_user(uid)
                if not u["conns"] or not u.get("rules"):
                    continue
                cutoff = int((time.time() - 2 * 86400) * 1000)
                for k in u["cursor"]:
                    u["cursor"][k] = min(u["cursor"][k], cutoff)
                trades, _ = pull(u)
                brake_check(uid, u, trades)
                save_user(uid, u)
            except Exception:
                continue
        if not page.get("IsTruncated"):
            break
        token = page["NextContinuationToken"]
    return {"statusCode": 200, "body": "ok"}


def health():
    """Проверка настройки без секретов: открыть адрес функции в браузере."""
    env = {k: bool(os.environ.get(k)) for k in ("BOT_TOKEN", "RATIO_KEY", "BUCKET", "S3_KEY_ID", "S3_SECRET", "LLM_KEY", "LLM_MODEL")}
    out = {"ratio": "ok", "env": env}
    try:
        Fernet(os.environ["RATIO_KEY"].encode())
        out["ratio_key"] = "ok"
    except Exception as e:
        out["ratio_key"] = f"ошибка: {type(e).__name__}"
    try:
        s3.head_bucket(Bucket=BUCKET)
        out["bucket"] = "ok"
    except Exception as e:
        out["bucket"] = f"ошибка: {type(e).__name__} {str(e)[:120]}"
    out["ccxt"] = getattr(ccxt, "__version__", "?")
    return out


ACTIONS = {"connect": act_connect, "disconnect": act_disconnect, "sync": act_sync, "coach": act_coach}


def handler(event, context):
    if event.get("messages") and event["messages"][0].get("event_metadata", {}).get("event_type", "").endswith("TimerMessage"):
        return on_timer()
    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 204, "headers": CORS, "body": ""}
    if event.get("httpMethod") == "GET":
        return {"statusCode": 200, "headers": CORS, "body": json.dumps(health(), ensure_ascii=False)}
    try:
        raw = event.get("body") or ""
        if raw and event.get("isBase64Encoded"):
            raw = base64.b64decode(raw).decode()
        b = json.loads(raw or "{}")
        if not FERNET or not BUCKET or not BOT_TOKEN:
            raise UserError("Сервер не настроен")
        uid = check_init_data(b.get("initData", ""))
        fn = ACTIONS.get(b.get("action"))
        if not fn:
            raise UserError("Неизвестное действие")
        return {"statusCode": 200, "headers": CORS, "body": json.dumps(fn(uid, b), ensure_ascii=False)}
    except UserError as e:
        return {"statusCode": 400, "headers": CORS, "body": json.dumps({"error": str(e)}, ensure_ascii=False)}
    except Exception as e:
        print("ERR", type(e).__name__, e)
        return {"statusCode": 500, "headers": CORS, "body": json.dumps({"error": f"Ошибка сервера ({type(e).__name__}), попробуйте позже"}, ensure_ascii=False)}
